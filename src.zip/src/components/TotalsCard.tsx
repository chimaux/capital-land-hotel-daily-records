import { money } from '../types'
import type { DepartmentEntry } from '../types'
import { Card, CardTitle, TotalRow } from './ui'

interface Props {
  entries: DepartmentEntry[]
  totalExpenses: number
}

function sumDept(entries: DepartmentEntry[], dept: string) {
  const e = entries.find((x) => x.department === dept)
  return e ? e.cash + e.pos + e.transfer : 0
}

export function TotalsCard({ entries, totalExpenses }: Props) {
  const cash = entries.reduce((s, e) => s + e.cash, 0)
  const pos = entries.reduce((s, e) => s + e.pos, 0)
  const transfer = entries.reduce((s, e) => s + e.transfer, 0)
  const income = cash + pos + transfer
  const net = income - totalExpenses

  return (
    <Card>
      <CardTitle>Day totals</CardTitle>
      <div className="grid grid-cols-3 gap-2 mb-4">
        <Kpi label="Income" value={money(income)} />
        <Kpi label="Expenses" value={money(totalExpenses)} />
        <Kpi label="Net" value={money(net)} tone={net < 0 ? 'neg' : 'pos'} />
      </div>
      <TotalRow label="Room" value={money(sumDept(entries, 'room'))} />
      <TotalRow label="Bar" value={money(sumDept(entries, 'bar'))} />
      <TotalRow label="Kitchen" value={money(sumDept(entries, 'kitchen'))} />
      <div className="my-2 border-t border-zinc-100 dark:border-zinc-800" />
      <TotalRow label="Total cash" value={money(cash)} />
      <TotalRow label="Total POS" value={money(pos)} />
      <TotalRow label="Total transfer" value={money(transfer)} />
      <TotalRow label="Total income" value={money(income)} grand />
      <TotalRow label="Total expenses" value={money(totalExpenses)} />
      <TotalRow label="Net for the day" value={money(net)} grand />
    </Card>
  )
}

function Kpi({ label, value, tone }: { label: string; value: string; tone?: 'pos' | 'neg' }) {
  const color = tone === 'neg' ? 'text-red-600 dark:text-red-400' : tone === 'pos' ? 'text-emerald-600 dark:text-emerald-400' : ''
  return (
    <div className="rounded-lg bg-zinc-50 dark:bg-zinc-800/50 border border-zinc-100 dark:border-zinc-800 px-2.5 py-2 min-w-0">
      <div className="text-[11px] text-zinc-500 dark:text-zinc-400">{label}</div>
      <div className={`text-sm font-semibold tabular-nums truncate ${color}`}>{value}</div>
    </div>
  )
}
